﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace hw0316
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlElement name_cn = null, name_en = null, post = null;
            XmlElement root = null;//最外面的节点
            XmlDocument doc = new XmlDocument();

            try{
                /*
                doc.Load("ZhToEn.xml");
                root = doc.DocumentElement;
                Console.WriteLine("Success");
                */
                XmlTextReader readerXml = new XmlTextReader("ZhToEn.xml");
                while (readerXml.Read())
                {
                    if (readerXml.NodeType == XmlNodeType.Element)
                    {

                        if (readerXml.Name == "Col1")
                        {
                            Console.Write("邮编：    ");
                            Console.WriteLine(readerXml.ReadElementString().Trim());
                        }
                        if (readerXml.Name == "Col2")
                        {
                            Console.Write("地址：    ");
                            Console.WriteLine(readerXml.ReadElementString().Trim());
                        }
                        if (readerXml.Name == "Col3")
                        {
                            Console.Write("英文地址："); 
                            Console.WriteLine(readerXml.ReadElementString().Trim());
                        }
                        Console.WriteLine();
                    }
                }
                




            }
            catch (Exception)
            {
                Console.WriteLine("Err");
                 throw;
            }
            Console.ReadKey();

        }
    }
}
